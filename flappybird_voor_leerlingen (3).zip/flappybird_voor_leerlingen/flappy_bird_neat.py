"""
The classic game of flappy bird, but now it's selflearning. Implemented in python and pygame,
with NEAT python AI library, following along Tech with Tim's tutorial "AI plays Flappy Bird". Thanx Tim!

Date Modified:  August 12, 2024 & August 21, 2025
Author: meester Bart
"""
# dingen die geïmporteerd worden van buitenaf om de game te laten werken
import pygame
import random
import os
import time
import neat
#import visualize
import pickle # voor de beste vogel op te slaan 
pygame.font.init()  # init font

# instellingen voor scherm zoals de afmetingen en lettertypes
WIN_WIDTH = 600
WIN_HEIGHT = 800
FLOOR = 730
STAT_FONT = pygame.font.SysFont("comicsans", 50)
END_FONT = pygame.font.SysFont("comicsans", 70)
DRAW_LINES = False

WIN = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
pygame.display.set_caption("Flappy Bird")

# plaatjes van alle items die in de game voorkomen

pipe_img = pygame.transform.scale2x(pygame.image.load(os.path.join("imgs","pipe.png")).convert_alpha())
bg_img = pygame.transform.scale(pygame.image.load(os.path.join("imgs","bg.png")).convert_alpha(), (600, 900))
bird_images = [pygame.transform.scale2x(pygame.image.load(os.path.join("imgs","bird" + str(x) + ".png"))) for x in range(1,4)]
base_img = pygame.transform.scale2x(pygame.image.load(os.path.join("imgs","base.png")).convert_alpha())

gen = 0 # begin van de training hoeveel generaties er zijn getrained

class Bird:
    # het vogeltje zelf met plaatje en bewegingen die, die kan uitvoeren
    MAX_ROTATION = 25
    IMGS = bird_images
    ROT_VEL = 20
    ANIMATION_TIME = 5

    def __init__(self, x, y):
        # stelt de eigenschappen van de vogel in
        self.x = x
        self.y = y
        self.tilt = 0  # degrees to tilt
        self.tick_count = 0
        self.vel = 0
        self.height = self.y
        self.img_count = 0
        self.img = self.IMGS[0]

    def jump(self):
       # het vogeltje laten springen
        self.vel = -10.5
        self.tick_count = 0
        self.height = self.y

    def move(self):
        # het vogeltje laten bewegen
        self.tick_count += 1

        displacement = self.vel*(self.tick_count) + 0.5*(3)*(self.tick_count)**2 

        if displacement >= 16:
            displacement = (displacement/abs(displacement)) * 16

        if displacement < 0:
            displacement -= 2

        self.y = self.y + displacement

        if displacement < 0 or self.y < self.height + 50:  
            if self.tilt < self.MAX_ROTATION:
                self.tilt = self.MAX_ROTATION
        else: 
            if self.tilt > -90:
                self.tilt -= self.ROT_VEL

    def draw(self, win):
        # het tekenen van het vogeltje
        self.img_count += 1

        # animatie van het vogeltje die wisselt tussen 3 soorten afbeeldingen van het vogeltje voor het op en neer gaan
        if self.img_count <= self.ANIMATION_TIME:
            self.img = self.IMGS[0]
        elif self.img_count <= self.ANIMATION_TIME*2:
            self.img = self.IMGS[1]
        elif self.img_count <= self.ANIMATION_TIME*3:
            self.img = self.IMGS[2]
        elif self.img_count <= self.ANIMATION_TIME*4:
            self.img = self.IMGS[1]
        elif self.img_count == self.ANIMATION_TIME*4 + 1:
            self.img = self.IMGS[0]
            self.img_count = 0

        if self.tilt <= -80:
            self.img = self.IMGS[1]
            self.img_count = self.ANIMATION_TIME*2


        blitRotateCenter(win, self.img, (self.x, self.y), self.tilt)

    def get_mask(self):
       # een masker die controleert of een vogeltje tegen een pijp aan vliegt
        return pygame.mask.from_surface(self.img)


class Pipe():
    GAP = 160 #hoe groot het gat is tussen de twee pijpen 
    VEL = 5 #hoeveel pixels die naar voren gaat per FRAME. De game staat op 100 fps dus 500 pixels per seconden.

    def __init__(self, x):
        # het aanmaken van de pijpen in het spel
        self.x = x
        self.height = 0

        # waar de boven- en onderkant van de pijp is
        self.top = 0
        self.bottom = 0

        self.PIPE_TOP = pygame.transform.flip(pipe_img, False, True)
        self.PIPE_BOTTOM = pipe_img

        self.passed = False

        self.set_height()

    def set_height(self):
        # hoogte van de pijp instellenm
        self.height = random.randrange(50, 450)
        self.top = self.height - self.PIPE_TOP.get_height()
        self.bottom = self.height + self.GAP

    def move(self):
        # bewegen van de pijpen
        self.x -= self.VEL

    def draw(self, win):
        # boven en onderkant van de pijpen tekenen
        win.blit(self.PIPE_TOP, (self.x, self.top))
        win.blit(self.PIPE_BOTTOM, (self.x, self.bottom))


    def collide(self, bird, win):
        # controle of het vogeltje tegen een van de buizen aanbotst
        bird_mask = bird.get_mask()
        top_mask = pygame.mask.from_surface(self.PIPE_TOP)
        bottom_mask = pygame.mask.from_surface(self.PIPE_BOTTOM)
        top_offset = (self.x - bird.x, self.top - round(bird.y))
        bottom_offset = (self.x - bird.x, self.bottom - round(bird.y))

        b_point = bird_mask.overlap(bottom_mask, bottom_offset)
        t_point = bird_mask.overlap(top_mask,top_offset)

        if b_point or t_point:
            return True

        return False

class Base:
    # de bewegende vloer in het spellejte
    VEL = 5
    WIDTH = base_img.get_width()
    IMG = base_img

    def __init__(self, y):
        # aanmaken van de grond
        self.y = y
        self.x1 = 0
        self.x2 = self.WIDTH

    def move(self):
        # het bewegen van de vloer
        self.x1 -= self.VEL
        self.x2 -= self.VEL
        if self.x1 + self.WIDTH < 0:
            self.x1 = self.x2 + self.WIDTH

        if self.x2 + self.WIDTH < 0:
            self.x2 = self.x1 + self.WIDTH

    def draw(self, win):
        # tekenen van de vloer die bestaat uit 2 plaatjes
        win.blit(self.IMG, (self.x1, self.y))
        win.blit(self.IMG, (self.x2, self.y))


def blitRotateCenter(surf, image, topleft, angle):
    # zorgt dat afbeeldingen kunnen draaien
    rotated_image = pygame.transform.rotate(image, angle)
    new_rect = rotated_image.get_rect(center = image.get_rect(topleft = topleft).center)

    surf.blit(rotated_image, new_rect.topleft)

def draw_window(win, birds, pipes, base, score, gen, pipe_ind):
    # zorgt dat alles in de game wordt getekend en bij gewerkt
    if gen == 0:
        gen = 1
    win.blit(bg_img, (0,0))

    for pipe in pipes:
        pipe.draw(win)

    base.draw(win)
    for bird in birds:
        # hulplijnen tekenen
        if DRAW_LINES:
            try:
                pygame.draw.line(win, (255,0,0), (bird.x+bird.img.get_width()/2, bird.y + bird.img.get_height()/2), (pipes[pipe_ind].x + pipes[pipe_ind].PIPE_TOP.get_width()/2, pipes[pipe_ind].height), 5)
                pygame.draw.line(win, (255,0,0), (bird.x+bird.img.get_width()/2, bird.y + bird.img.get_height()/2), (pipes[pipe_ind].x + pipes[pipe_ind].PIPE_BOTTOM.get_width()/2, pipes[pipe_ind].bottom), 5)
            except:
                pass
        # teken vogeltje
        bird.draw(win)

    # score
    score_label = STAT_FONT.render("Score: " + str(score),1,(255,255,255))
    win.blit(score_label, (WIN_WIDTH - score_label.get_width() - 15, 10))

    # generaties
    score_label = STAT_FONT.render("Gens: " + str(gen-1),1,(255,255,255))
    win.blit(score_label, (10, 10))

    # levend
    score_label = STAT_FONT.render("Alive: " + str(len(birds)),1,(255,255,255))
    win.blit(score_label, (10, 50))

    pygame.display.update()


def eval_genomes(genomes, config):
# fitness functie de vogel begint met 0 punten. Het vogeltje krijgt punten voor goede dingen zoals een pijp passeren of lang overleven. Het vogeltje krijgt -1 als die dood gaat. Het vogeltje met de meeste punten brengt de volgende generatie voort die dan kleine aanpassing krijgt. De beste vogel wordt opgeslagen met de pickle in mapje winner.pkl
    
    global WIN, gen 
    win = WIN
    gen += 1

    nets = []
    birds = []
    ge = []
    
    for genome_id, genome in genomes:
        genome.fitness = 0 # begin aantal punten
        net = neat.nn.FeedForwardNetwork.create(genome, config)
        nets.append(net)
        birds.append(Bird(230,350))
        ge.append(genome)

    base = Base(FLOOR)
    pipes = [Pipe(700)]
    score = 0 # beginscore 

    clock = pygame.time.Clock()

    run = True
    while run and len(birds) > 0:
        clock.tick(100) #fps

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                quit()
                break

        # om automatisch te stoppen als er een bird is die de 1000 haald. 
        if score > 1000:
            run = False
            break

        pipe_ind = 0
        if len(birds) > 0:
            if len(pipes) > 1 and birds[0].x > pipes[0].x + pipes[0].PIPE_TOP.get_width():
                pipe_ind = 1
        
        for x, bird in enumerate(birds):
            ge[x].fitness += 0.1 #punten die de vogel krijgt voor levend te blijven. dus omdat de fps op 100 staat krijgt een vogeltje 100 x 0.1 punten per seconden. 
            bird.move()

            output = nets[birds.index(bird)].activate((bird.y, abs(bird.y - pipes[pipe_ind].height), abs(bird.y - pipes[pipe_ind].bottom)))

            if output[0] > 0.5:
                bird.jump()

        base.move()

        rem = []
        add_pipe = False
        for pipe in pipes:
            pipe.move()
            
            for bird in birds:
                if pipe.collide(bird, win):
                    ge[birds.index(bird)].fitness -= 1 #het verlies vanpunten door een pipe te raken. 
                    nets.pop(birds.index(bird))
                    ge.pop(birds.index(bird))
                    birds.pop(birds.index(bird))

            if pipe.x + pipe.PIPE_TOP.get_width() < 0:
                rem.append(pipe)

            if not pipe.passed and pipe.x < bird.x:
                pipe.passed = True
                add_pipe = True

        if add_pipe:
            score += 1 # heeft niet iets met de trainingsfunctie te maken, maar gewoon met het aantal punten die je behaald dus voor elke pijp de je paseert. 
            
            for genome in ge:
                genome.fitness += 5 #dit is et aantal punten die je in de training krijgt voor het passeren van een pijp. 
            
            pipes.append(Pipe(WIN_WIDTH))

        for r in rem:
            pipes.remove(r)

        for bird in birds:
            if bird.y + bird.img.get_height() - 10 >= FLOOR or bird.y < -50:
                nets.pop(birds.index(bird))
                ge.pop(birds.index(bird))
                birds.pop(birds.index(bird))

        draw_window(WIN, birds, pipes, base, score, gen, pipe_ind)

def run(config_file):
    # NEAT wordt klaargezet om een neuraal netwerk te trainen
    config = neat.config.Config(neat.DefaultGenome, neat.DefaultReproduction,
                         neat.DefaultSpeciesSet, neat.DefaultStagnation,
                         config_file)

    # de populatie genereren
    p = neat.Population(config)

    p.add_reporter(neat.StdOutReporter(True))
    stats = neat.StatisticsReporter()
    p.add_reporter(stats)
    #.add_reporter(neat.Checkpointer(5))

    # het trainingsproces gaat tot maximaal 10 generaties
    winner = p.run(eval_genomes, 10) 

    # laat de statistieken van het beste vogeltje zien
    print('\nBest genome:\n{!s}'.format(winner))
    
    # sla het beste vogeltje op in een bestand
    with open("winner.pkl", "wb") as f:
        pickle.dump(winner, f)

if __name__ == '__main__':
    # zorgt dat alles gaat draaien
    local_dir = os.path.dirname(__file__)
    config_path = os.path.join(local_dir, 'config-feedforward.txt')
    run(config_path)
    pygame.quit()