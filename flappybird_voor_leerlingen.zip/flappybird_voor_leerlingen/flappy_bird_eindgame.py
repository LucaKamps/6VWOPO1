
import os
import pickle
import pygame
import neat

# Import the existing game classes and drawing functions.
from flappy_bird_neat import (
    Bird,
    Pipe,
    Base,
    draw_window,
    WIN,
    WIN_WIDTH,
    FLOOR,
)

pygame.init()

def play_with_best_bird(config_path, winner_path):
    """Play Flappy Bird using the saved winner genome."""

    # Load the same NEAT configuration used during training.
    config = neat.config.Config(
        neat.DefaultGenome,
        neat.DefaultReproduction,
        neat.DefaultSpeciesSet,
        neat.DefaultStagnation,
        config_path
    )

    # Load the previously saved winner.
    with open(winner_path, "rb") as file:
        winner = pickle.load(file)

    # Create the neural network from the saved genome.
    net = neat.nn.FeedForwardNetwork.create(winner, config)

    bird = Bird(230, 350)
    base = Base(FLOOR)
    pipes = [Pipe(700)]
    score = 0
    clock = pygame.time.Clock()
    playing = True

    while playing:
        clock.tick(100)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                playing = False

        if not playing:
            break

        # Select the next pipe.
        pipe_ind = 0
        if (
            len(pipes) > 1
            and bird.x > pipes[0].x + pipes[0].PIPE_TOP.get_width()
        ):
            pipe_ind = 1

        # Let the saved neural network control the bird.
        bird.move()
        output = net.activate((
            bird.y,
            abs(bird.y - pipes[pipe_ind].height),
            abs(bird.y - pipes[pipe_ind].bottom)
        ))

        if output[0] > 0.5:
            bird.jump()

        # Move the pipes and the base.
        base.move()
        pipes_to_remove = []

        for pipe in pipes:
            pipe.move()

            if not pipe.passed and pipe.x < bird.x:
                pipe.passed = True
                score += 1

            if pipe.x + pipe.PIPE_TOP.get_width() < 0:
                pipes_to_remove.append(pipe)

        for pipe in pipes_to_remove:
            pipes.remove(pipe)

        # Add another pipe when needed.
        if pipes and pipes[-1].x < WIN_WIDTH - 300:
            pipes.append(Pipe(WIN_WIDTH))

        # Check for collisions.
        hit_pipe = any(pipe.collide(bird, WIN) for pipe in pipes)
        hit_floor = bird.y + bird.img.get_height() - 10 >= FLOOR
        hit_ceiling = bird.y < -50

        if hit_pipe or hit_floor or hit_ceiling:
            playing = False

        # Draw the game.
        draw_window(WIN, [bird], pipes, base, score, 1, pipe_ind)

    print("Score of saved winner:", score)


if __name__ == "__main__":
    local_dir = os.path.dirname(os.path.abspath(__file__))

    config_path = os.path.join(
        local_dir, "config-feedforward.txt"
    )
    winner_path = os.path.join(
        local_dir, "winner.pkl"
    )

    if os.path.exists(winner_path):
        play_with_best_bird(config_path, winner_path)
    else:
        print("winner.pkl not found. Run the training script first.")

    pygame.quit()
